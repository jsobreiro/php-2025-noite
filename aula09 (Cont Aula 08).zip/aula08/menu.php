<nav class="nav">
    <a class="nav-link" href="index.php">Home</a>
    <a class="nav-link" href="clientes.php">Clientes Cadastrados</a>
</nav>